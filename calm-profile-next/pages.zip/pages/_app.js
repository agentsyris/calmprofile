import '../styles/index.css';
import '../styles/syris-premium.css';

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />;
}